export default class SortContainer {
    constructor() {
    }
}