<?php

namespace Application\abstracts;

abstract class RequestImageSetAbstract extends ModelDefaultFunctions
{
    public $set_id;

    public $user_id;

    public $request_id;

    public $reference;


    public $db_status;

    public $date_created;

}