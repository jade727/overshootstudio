<?php

namespace Application\abstracts;

 abstract class ResultImageAbstract extends ModelDefaultFunctions
{
    public $image_id;

    public $reference;

    public $image;

     public $db_status;


    public $date_created;
}